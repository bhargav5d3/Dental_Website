# Future Ready Talent Virtual Internship Project
This is the project created for Microsoft Future Ready Talent Virtual Internship Program
# Industry Name
Health
# Project Title
dental health
# Problem Statement/Opportunity
This is a responsive website that includes information about Dental health . This website includes Home, About Us, Services, Blog, Contact us tabs. This web application will help us to know about Dental Services, some best Dentists and their Achievements. Patients can also see latest news & events related to Dental Care. Patients can book their appointment by submitting some basic details.
# Project Description
Dental health  is consists of six sections that are like Home, About Us, Services, News, Blog, and Contact Us, one can book an appointment by clicking on Contact Us button. I have used HTML5, JS and CSS for this website. And I have used Visual Studio code editor. The Home page contains the general introduction of the Dental health. Next tab is About Us that contains information of some best dentists. Next is the Services tab which includes services offered by My Dental Buddy. News tab includes past events & news articles with some photographs. Blog contain a snapshot of happy clients, some insides of the clinic, infrastructure, and laboratory. The blog tab also contains some of the latest news. Contact Us tab contains an area to ask questions and click send button. Patients can submit their basic details and book their appointments.
# Primary Azure Technologies
Static Web Apps,azure health bot
# Azure Link
https://nice-forest-05fcab100.2.azurestaticapps.net
# Github Page Link
https://github.com/BHOOMIREDDYBHARGAVREDDY/project22
# Project Demo Video URL
https://youtu.be/mj_8FEwc0yg
# Screenshot of Website
<img width="947" alt="anvi-rak" src="https://user-images.githubusercontent.com/111232373/213192243-8387a3c1-4244-4990-a465-efa977365d23.PNG">
<img width="932" alt="dd" src="https://user-images.githubusercontent.com/111232373/203811266-5130a56b-6264-46fb-9636-9410a32e06e7.PNG"
<img width="912" alt="g" src="https://user-images.githubusercontent.com/111232373/203811845-319abb37-a4a3-4816-a98a-f71df2619a0d.PNG">
<img width="924" alt="c" src="https://user-images.githubusercontent.com/111232373/203812128-eb956cf4-1052-40a1-882e-2cc59c540247.PNG">
<img width="658" alt="anvi-ra" src="https://user-images.githubusercontent.com/111232373/213191058-7c6d0c6e-609c-4e2e-a2eb-7072874c3b30.PNG">

